$('#button-addon2').click(getEvents);


function getEvents() {
    // Clear before adding in case the user clicks the button twice
    $('#results').empty();
    const classification = $('#classification').val();
    const city = $('#city').val();
    $.ajax({
        type: "GET",
        url: "https://app.ticketmaster.com/discovery/v2/events.json?apikey=v9I9u0Cd8x7LBlYmhCoNH8SodUerO9vn",
        data: {sort: 'date,asc', classificationName: classification, city: city},
        async: true,
        dataType: "json",
        success: function (data) {
            console.log(data);
            let results;
            let resultsLength;
            if (!(data._embedded === undefined)) {
                results = data._embedded.events;
                resultsLength = results.length;
            } else {
                resultsLength = 0;
                results = 'none';
            }
            if (!(jQuery.isEmptyObject(classification) || jQuery.isEmptyObject(city))) {
                $('#searchEmpty').empty();
                console.log('hello2');
                if (resultsLength > 0) {

                    $('#results').empty().append('                    <div class=" col-12">\n' +
                        `<p class="fw-bold fs-4 text-start justify-content-start text-secondary mt-3 ">${resultsLength} events found</p>\n` + '     </div>\n');

                    $.each(data._embedded.events, function (i, event) {
                        console.log(event._embedded.venues);
                        const eventName = event.name
                        const eventImage = event.images[0].url
                        const startDate = event.dates.start.dateTime;
                        const localTime = event.dates.start.localTime;
                        const formatlocalTime = new Date(startDate).toLocaleTimeString(navigator.language, {
                            hour: 'numeric',
                            minute: '2-digit'
                        });
                        const formatDate = new Date(startDate).toDateString();
                        const venueName = event._embedded.venues[0].name;
                        const venueCity = event._embedded.venues[0].city.name;
                        const venueState = event._embedded.venues[0].state.name;
                        const venueAddress1 = event._embedded.venues[0].address.line1;

                        const eventUrl = event.url;
                        console.log(eventName, eventImage, formatDate, venueName, venueCity, venueState, eventUrl);

                        $('#results').append('' +
                            '' +

                            //   '<section class="shadow">' +
                            //   '          <div class="row g-0  align-items-center justify-content-center text-start">\n' +
                            '   <div class=" col-12">\n' +
                            '        <div class="card h-100 my-3  shadow justify-content-center">\n' +
                            '              <div class="row g-0  align-items-center justify-content-center text-start">\n' +
                            '                   <div class="col-lg-4">\n' +
                            `                        <img class="card-img rounded " src=${eventImage}  alt="profile-image">\n` +
                            '                    </div>\n' +
                            '                    <div class="col-lg-8">\n' +
                            '                          <div class="card-body">\n' +
                            '                               <div class="row g-0  align-items-start justify-content-center text-start">\n' +
                            '                                     <div class="col-6 pt-4">\n' +
                            `                                          <h4 class="card-title">${eventName}</h4>\n` +
                            `                                          <h5 class="card-text text-secondary my-4">${venueName}</h5>\n` +
                            `                                          <p class="card-text text-secondary mb-0 pb-0">${venueAddress1}</p>\n` +
                            `                                          <p class="card-text text-secondary mt-0 pt-0">${venueCity}, ${venueState}</p>\n` +
                            `                                          <a href="${eventUrl}" target="#" > <button type="button" class="btn bg-primary text-white"> Find tickets</button></a>\n` +

                            '                                     </div>\n' +
                            '                                     <div class="col-6 text-success text-end fw-bold">\n' +
                            `                                           <h3 class="card-text  ">${formatDate}</h3>\n` +
                            `                                           <p class="card-text fs-5">${formatlocalTime}</p>\n` +

                            '                                     </div>\n' +
                            '                               </div>\n' +
                            '                          </div>\n' +
                            '                       </div>\n' +
                            '                   </div>\n' +
                            '              </div>\n' +
                            '         </div>\n' +
                            '    </div>\n'

                            // '</section>'
                        );


                    });
                } else {

                    $('#results').empty().append('<div class="col-12 fs-5 py-3 text-start">Sorry ... No results were found for the entered search term or city.</div>\n');
                }
            } else {
                console.log('hello');
                $('#searchEmpty').empty().append('<div class="alert alert-danger text-start" role="alert">Search term cannot be empty. Pleaser enter a search term.</div>\n');
            }
            // Parse the response.
            // Do other things.
        },
        error: function (xhr, status, err) {
            // This time, we do not end up here!
        }
    });


}

